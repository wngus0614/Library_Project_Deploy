CREATE DATABASE  IF NOT EXISTS `library` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `library`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: localhost    Database: library
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_wish`
--

DROP TABLE IF EXISTS `tbl_wish`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_wish` (
  `wish_id` int NOT NULL AUTO_INCREMENT,
  `wish_title` varchar(45) NOT NULL,
  `wish_author` varchar(45) NOT NULL,
  `wish_publisher` varchar(45) NOT NULL,
  `wish_year` int NOT NULL,
  `wish_isbn` varchar(45) DEFAULT NULL,
  `wish_regdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `user_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`wish_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_wish`
--

LOCK TABLES `tbl_wish` WRITE;
/*!40000 ALTER TABLE `tbl_wish` DISABLE KEYS */;
INSERT INTO `tbl_wish` VALUES (1,'타이탄의 도구들','티모시 페리스','토네이도',2022,'9791158510619','2023-10-16 02:13:16','KIG1111'),(2,'세이노의 가르침','세이노','데이원',2023,'9791168473690','2023-10-16 02:45:35','LCJ1111'),(5,'ㅁㄴㅇㄹ','ㅁㄴㅇㄹ','ㅁㄴㅇㄹ',123,'ㅁㅇㄴㄻㄴㄹㅇ','2023-10-17 07:09:22',''),(6,'ㅁㅇㄴㄻ','ㅁㅇㄻㄴㅇㄹ','ㅁㄴㄹㅇㅇㅁㄴㄹ',1566,'ㅁㄴㅇㄻㄴㅇㄻㄴㅇ','2023-10-17 07:10:25',''),(7,'ㄴㄻㄴㅇ','ㅁㄴㅇㄻㄴㅇㄹ','ㄴㄹㅇㅁㄴㅇㄻㄴㅇㄹㄴㄹㅇㅁ',1234,'ㅁㄴㅇㄻㄴㄹㅇㅇㅁㄹㄴ','2023-10-17 07:14:41',''),(8,'ㅁㄴㅇㄹㄴㅇㄹ','ㅁㄴㅇㄻㄴㅇㄹㅇㄹㄴㅁ','ㄴㅇㄻㅇㄹㄴㅁㅇㄹㄴㅁ',15632,'ㅁㄴㄹㅇㅁㄴㅇㄹㅇㅁㄴㄹ','2023-10-17 07:18:07',''),(9,'ㅁㅇㄴㄹdsf','ㅁㄴㅇㄹ','ㅁㅇㄴㄹ',1231,'','2023-10-17 15:58:21',''),(10,'adsffads','sfdafd','sdfafsdasfda',0,'','2023-10-17 16:03:34',''),(11,'adfsafsd','sadffsad','sfdasfad',21321,'vzzcxvzcv','2023-10-17 16:05:53',''),(12,'wereaf','fadsadfasfd','safdasfdfds',1623,'asdfafdafds','2023-10-18 00:26:06',''),(13,'asfdasdfafd','fas','asdfdfsaasfd',2654,'sdafsadfsdaf','2023-10-18 00:47:39','usertest1'),(14,'테스트','테스트','테스트',2023,'TEST1234','2023-10-18 01:50:07','usertest1'),(15,'ajskldgjaslkdgjlksda','sakdjflkasdgjlksadjg','jkasdgjlkasjgklsadjglkas',1991,'asdglkasdklgjaklsd1123123','2023-10-24 03:32:29','usertest1'),(16,'asdgasgegaet','어쩌라고','제발좀!!',1992,'asjgklasjgkl1234','2023-10-24 03:35:48','usertest1');
/*!40000 ALTER TABLE `tbl_wish` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-25 11:15:21
